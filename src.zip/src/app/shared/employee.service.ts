import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import 'rxjs/operator/map';
import 'rxjs/operator/toPromise';

import { Employee, searchByName, getFullEmpByIdRequest } from './employee.model';

@Injectable()
export class EmployeeService {
  selectedEmployee: Employee;
  employees: Employee[];
  readonly baseURL = 'https://murmuring-escarpment-52363.herokuapp.com/employees';
  //readonly baseURL = 'http://localhost:3000/employees';

  constructor(private http: HttpClient) { }

  postEmployee(emp: Employee) {
    return this.http.post(this.baseURL, emp);
  }

  getEmployeeList() {
    return this.http.get(this.baseURL);
  }

  putEmployee(emp: Employee) {
    return this.http.put(this.baseURL + `/${emp._id}`, emp);
  }

  deleteEmployee(_id: string) {
    return this.http.delete(this.baseURL + `/${_id}`);
  }

  getEmployeeByKeyword(key: searchByName){
    return this.http.post(this.baseURL+'/search' ,key)
  }

  updateEmp(emp: Employee){
    return this.http.post(this.baseURL+'/updateEmp' ,emp)
  }

  createEmp(emp: Employee){
    return this.http.post(this.baseURL+'/createEmp' ,emp)
  }

  getFullEmp(request:getFullEmpByIdRequest ){
    return this.http.post(this.baseURL+'/getFullEmp' ,request)
  }

  deleteEmp(request:getFullEmpByIdRequest){
    return this.http.post(this.baseURL+'/deleteEmp' ,request)
  }

}
