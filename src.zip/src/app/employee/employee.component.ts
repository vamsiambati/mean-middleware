import { Component, OnInit } from '@angular/core';
import { NgForm, FormGroup, FormControl, Validators } from '@angular/forms';

import { EmployeeService } from '../shared/employee.service';
import { Employee, searchByName, getFullEmpByIdRequest } from '../shared/employee.model';

declare var M: any;

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css'],
  providers: [EmployeeService]
})
export class EmployeeComponent implements OnInit {
  employeeForm: FormGroup;
  searchByNameKey:string ='';
  showNoResultsMessage:boolean =false;
  base64DataOfImage :string;
  fileSrc:string;
  files:any;
  isEdit:boolean;
  isBusy:boolean =false;

  constructor(public employeeService: EmployeeService,) { }

  ngOnInit() {
    this.createForm();
    this.resetForm();
    this.refreshEmployeeList();
  }
  
  search():void{
    let request = new searchByName;
    request.name=this.searchByNameKey;
    this.employeeService.getEmployeeByKeyword(request).subscribe((res) => {
      this.employeeService.employees = res as Employee[];
      if(this.employeeService.employees.length ===  0){
        this.showNoResultsMessage =true;
      }
      else this.showNoResultsMessage =false;
    });
    }

    
  resetForm() {
    this.employeeForm.reset();
    this.isEdit=false;
    this.base64DataOfImage='';
    this.employeeService.selectedEmployee = {
      _id: "",
      name: "",
      position: "",
      office: "",
      salary: null,
      imageData:""
    }
  }

  createForm() {
    this.employeeForm = new FormGroup({
      name: new FormControl(''),
      position: new FormControl(''),
      office: new FormControl(''),
      salary: new FormControl(''),
      imageData: new FormControl(''),
    });
  }
  submitNew(){
    this.isBusy = true;
    let request = new Employee;
      request.name = this.employeeForm.get('name').value;
      request.position = this.employeeForm.get('position').value;
      request.office = this.employeeForm.get('office').value;
      request.salary = this.employeeForm.get('salary').value;
      request.imageData = this.base64DataOfImage? this.base64DataOfImage:'';
      if(this.isEdit){
        request._id=this.employeeService.selectedEmployee._id;
        this.employeeService.updateEmp(request).subscribe((res) => {
          this.isEdit=false;
          this.resetForm()
                 this.refreshEmployeeList();
                 M.toast({ html: 'Updated successfully', classes: 'rounded' });
                 this.isBusy = false;
               });
      }
      else{
        this.employeeService.createEmp(request).subscribe((res) => {
          this.resetForm();
          this.refreshEmployeeList();
          M.toast({ html: 'Saved successfully', classes: 'rounded' });
          this.isBusy = false;
        });
      }
  }
  
  refreshEmployeeList() {
    this.employeeService.getEmployeeList().subscribe((res) => {
      this.employeeService.employees = res as Employee[];
      if(this.employeeService.employees.length ===  0){
        this.showNoResultsMessage =true;
      }
      else this.showNoResultsMessage =false;
    });
  }

  onEdit(emp: Employee) {
    this.isEdit= true;
    let request: getFullEmpByIdRequest = new getFullEmpByIdRequest;
    request.id=emp._id;
    this.employeeService.getFullEmp(request).subscribe((res) => {
      console.log(res);
      let selectedEmployee :Employee = res as Employee;
      this.employeeService.selectedEmployee = selectedEmployee;
      this.employeeForm.get('name').setValue(selectedEmployee.name);
      this.employeeForm.get('position').setValue(selectedEmployee.position);
      this.employeeForm.get('office').setValue(selectedEmployee.office);
      this.employeeForm.get('salary').setValue(selectedEmployee.salary);
      if(selectedEmployee.imageData){
        this.base64DataOfImage=selectedEmployee.imageData;
        this.fileSrc='data:image/png;base64,'+this.base64DataOfImage;
      }
    });
    //this.employeeService.selectedEmployee = emp;
   
  }

  onDelete(_id: string) {
    if (confirm('Are you sure to delete this record ?') == true) {
      let request:getFullEmpByIdRequest=new getFullEmpByIdRequest;
      request.id=_id
      this.employeeService.deleteEmp(request).subscribe((res) => {
        this.refreshEmployeeList();
        this.resetForm();
        M.toast({ html: 'Deleted successfully', classes: 'rounded' });
      });
    }
  }
  

  getFiles(event) {
    this.files = event.target.files;
    var reader = new FileReader();
    reader.onload = this._handleReaderLoaded.bind(this);
    reader.readAsBinaryString(this.files[0]);
}

_handleReaderLoaded(readerEvt) {
    var binaryString = readerEvt.target.result;
    this.base64DataOfImage= btoa(binaryString); 
    this.employeeService.selectedEmployee.imageData = this.base64DataOfImage
    this.fileSrc = 'data:image/png;base64,'+this.base64DataOfImage;
}
}
