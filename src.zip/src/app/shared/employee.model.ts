export class Employee {
    _id: string;
    name: string;
    position: string;
    office: string;
    salary: number;
    imageData: string;
}

export class searchByName{
    name:string
}

export class getFullEmpByIdRequest{
    id:string
}